# @huolitsija/shipment-map

The 3D live shipment map for the Huolitsija customer portal and ops console. It is one React component, `<ShipmentMap>`. It reads the map data contract (`shared/map-data-contract.md`): one snapshot, then live positions over Server-Sent Events, falling back to polling every 30 s. It draws every shipment on a globe that zooms smoothly down to Europe and Finland.

- **Globe and basemap:** MapLibre GL JS 5 globe projection (BSD-3) with deck.gl 9.4 layers (MIT) drawn into the same WebGL context. Icons are lucide (ISC).
- **Tiles:** [OpenFreeMap](https://openfreemap.org) Positron (light) and Dark vector styles. They are free for commercial use, with no account, no API key and no request limits. Attribution (OpenFreeMap © OpenMapTiles, data © OpenStreetMap contributors) shows in the map corner and must stay visible.
- **No generated imagery:** the basemap is vector data, so the map uses no textures or images.
- **Design system:** tokens are the Factory UI/UX handoff tokens (`ui-ux-archive`), copied verbatim and scoped to `.huo-map`. The host app's `:root` is never touched. Light and dark themes are both supported.

## What it shows

| Element | How |
|---|---|
| Routes | One line per lane. Shared lanes are drawn once and get thicker and darker with traffic. Colour is the mode series: sea `--chart-1` blue, road `--chart-7` emerald, rail `--chart-6` violet, air `--chart-3` magenta. Air legs are 3D arcs above the globe. |
| Moving markers | Each marker sits at `position` from the contract. Between reports it glides to the new position over the report interval (capped at 5 s), so it is never more than one report behind. Air markers ride on their arc. The colour is the mode of the leg the shipment is on now. Booked shipments are hollow; delivered ones are small and neutral. |
| Exceptions and customs holds | A red (exception) or amber (customs hold) ring with a slow pulse. They are drawn on top of everything else and listed first. The chip at the top reads **"N need attention · E exceptions · H customs holds (B both)"** and filters to them. Each category is counted on its own: a customs hold that also carries an exception is in both E and H, and B says how many. N is the distinct number of shipments, exactly what the filter shows. On phones the chip shows only N; the full breakdown is in its tooltip. |
| Filters | Mode chips with counts, status menu, customer select (ops, more than one customer) and free-text search over reference, customer, ports and carriers. Counts are faceted. Filters persist per scope in localStorage. |
| List | Windowed, so it stays fast at 2,000+ rows. Sorted attention first, then ETA. Arrow keys move the selection. |
| Side panel | Reference, customer, status, mode, origin → destination, progress and km to go, ETA (absolute and relative), and position source (AIS / GPS / Carrier feed / *Estimated from schedule*) with its age and a *Stale* tag. Then cargo, every leg with carrier and ETD/ATD/ETA/ATA, and **Open shipment**, which links to the detail page. The selected route is drawn solid where travelled and dashed ahead, with origin and destination labels. |
| Camera | World / Europe / Finland presets fly smoothly (2.6 s; instant with reduced motion). Plus zoom buttons, drag, wheel and pinch. Selecting from the list frames the whole route. |
| Live state | *Live* only when a snapshot has loaded and the stream is open; an open stream alone never reads as Live. Otherwise: *Connecting*, *Updating every 30 s* (polling), *Load failed · retrying in N s* (no snapshot has loaded yet; red; Retry), *Offline · retrying in N s* (data shown, no stream, refresh failing) or *Live · last refresh failed* (amber). A failed first load shows an error card with the reason and Retry, never "No shipments yet". A failed refresh keeps the data on screen with a banner giving the time of the last good data. Automatic retries back off 2 s, 4 s, 8 s … 60 s; Retry ignores the backoff. `connectionView(state)` is exported for hosts that show their own indicator. |
| Mobile (< 768 px container) | Search plus Filters and List sheets. The detail panel becomes a bottom sheet. Touch pan and pinch zoom work; rotation is off. |
| Languages | Finnish (default, as the design system says) and English, including the basemap's place names. |

## Install in the app (step s1, Emergent React front end)

Option A, the packed package (recommended). Copy `huolitsija-shipment-map-1.0.1.tgz` from this folder into the front end, then:

```bash
cd frontend
mkdir -p vendor && cp /path/to/shared/s2/huolitsija-shipment-map-1.0.1.tgz vendor/
yarn add file:./vendor/huolitsija-shipment-map-1.0.1.tgz     # or: npm i ./vendor/huolitsija-shipment-map-1.0.1.tgz
```

The package is one prebuilt ES2020 bundle with MapLibre, deck.gl and the icons inside. It has no runtime dependencies besides `react` and `react-dom` (18.2 or newer). The checks behind this:

- **CRA host build:** checked in a Create React App 5 + craco + React 19 + react-router 7 host. `craco build` passes.
- **Minifier warnings:** the CSS minifier prints `postcss-calc` warnings for the design tokens' relative-colour syntax (`oklch(from var(--x) … calc(c * .78) h)`). They are harmless; the tokens come out intact.
- **Lazy chunk size:** the map is about 518 kB gzip as its own chunk.

Option B, source: copy `src/` into the app and install `maplibre-gl@^5.24 @deck.gl/core@9.4 @deck.gl/layers@9.4 @deck.gl/mapbox@9.4 @deck.gl/extensions@9.4 lucide-react`. The source is TypeScript.

Import the stylesheet once, for example in `src/index.js`:

```js
import '@huolitsija/shipment-map/style.css';
```

## Mount it: portal and ops routes

Load it lazily so the map's WebGL code only downloads on the map routes. Give it a sized parent; it fills 100% of its parent.

```jsx
// src/pages/ShipmentMapPage.jsx
import { lazy, Suspense } from 'react';
import { useNavigate } from 'react-router-dom';

const ShipmentMap = lazy(() =>
  import('@huolitsija/shipment-map').then((m) => ({ default: m.ShipmentMap })),
);

export function PortalMapPage() {
  const navigate = useNavigate();
  return (
    <div style={{ height: 'calc(100vh - 56px)' }}>   {/* below the app header */}
      <Suspense fallback={null}>
        <ShipmentMap
          endpoint={`${process.env.REACT_APP_BACKEND_URL}/api/map/shipments`}
          scope="customer"
          fetchInit={{ credentials: 'include' }}                 // cookie session
          getHeaders={() => ({ Authorization: `Bearer ${localStorage.getItem('token')}` })} // or a bearer token
          onNavigate={(href) => navigate(href)}                   // /portal/shipments/<id>
          locale="fi"
        />
      </Suspense>
    </div>
  );
}

export function OpsMapPage() {
  const navigate = useNavigate();
  return (
    <div style={{ height: 'calc(100vh - 56px)' }}>
      <Suspense fallback={null}>
        <ShipmentMap
          endpoint={`${process.env.REACT_APP_BACKEND_URL}/api/map/shipments`}
          scope="ops"
          getHeaders={() => ({ Authorization: `Bearer ${localStorage.getItem('token')}` })}
          onNavigate={(href) => navigate(href)}                   // /ops/shipments/<id>
        />
      </Suspense>
    </div>
  );
}

// Routes
// <Route path="/portal/map" element={<PortalMapPage />} />
// <Route path="/ops/map" element={<OpsMapPage />} />
// Deep link: <ShipmentMap initialSelectedId={id} … /> opens with that shipment selected and framed.
```

**Theme:** by default the map follows `<html data-theme="dark|light">`, or the shadcn `.dark` class on `<html>`, then the OS setting. It reacts live when either changes. Pass `theme="light"` or `theme="dark"` to force one.

## Props (exact)

| Prop | Type | Default | Notes |
|---|---|---|---|
| `endpoint` | `string` | required | Snapshot URL, e.g. `/api/map/shipments`. `?scope=` is appended if missing. |
| `scope` | `'customer' \| 'ops'` | required | Sent as `?scope=` on both requests. It also picks the default detail link and hides the customer column and filter for customers. |
| `streamUrl` | `string \| null` | endpoint with `/shipments` → `/stream` | `null` = polling only. |
| `fetchInit` | `RequestInit` | `{}` | Merged into every request, e.g. `{ credentials: 'include' }`. |
| `getHeaders` | `() => Record<string,string> \| Promise<…>` | none | Called before every request, including stream reconnects. Use it for short-lived tokens. |
| `getDetailHref` | `(s: Shipment) => string` | `/portal/shipments/<id>` or `/ops/shipments/<id>` | Detail page URL. |
| `onNavigate` | `(href, shipment, event) => void` | none | SPA navigation for plain clicks. Ctrl/⌘/middle-click still open the href. |
| `onSelect` | `(s: Shipment \| null) => void` | none | Selection changes. |
| `initialSelectedId` | `string` | none | Opens with this shipment selected and framed. |
| `theme` | `'inherit' \| 'system' \| 'light' \| 'dark'` | `'inherit'` | See Theme above. |
| `locale` | `'fi' \| 'en'` | `'fi'` | All labels, dates (Europe/Helsinki), numbers and basemap place names. |
| `initialView` | `'world' \| 'europe' \| 'finland'` | `'world'` | Opening camera. |
| `pollIntervalMs` | `number` | `30000` | Polling interval when the stream is unavailable. |
| `stallTimeoutMs` | `number` | `45000` | Reconnects the stream after this long without bytes (half-open connections). The server must send `: ping` at least every 15 s. |
| `staleAfterMs` | `number` | 2 h | A position older than this gets a *Stale* tag. |
| `persistKey` | `string \| null` | `huo-map:<scope>` | localStorage key for filters; `null` turns persistence off. |
| `mapStyle` | `{ light, dark }` (style URL or object) | OpenFreeMap Positron / Dark | Swap the basemap, e.g. for a self-hosted style. |
| `showStats` | `boolean` | `false` | FPS readout, for performance checks. |
| `className`, `style` | | | Applied to the root `.huo-map`. |

Also exported: `ShipmentFeed`, the framework-free live-data client the component uses, plus `withScope`, `defaultStreamUrl` and all contract types (`Shipment`, `Leg`, `PositionEvent`, …).

## What the back end must do (FastAPI + MongoDB)

- **`GET /api/map/shipments?scope=customer|ops`:** exactly the contract. Customer scope returns only the caller's company. Shipments that break the contract (no id, legs or numeric position) are skipped and logged client-side; the rest still render.
- **Compression:** gzip the snapshot. 2,000 shipments with full lane geometry are about 11 MB of JSON, or 2.1 MB gzipped. Add `app.add_middleware(GZipMiddleware, minimum_size=1024)`.
- **SSE and gzip:** keep SSE out of gzip. Starlette ≥ 0.40 already excludes `text/event-stream`; with an older version, mount the stream before the middleware or exclude it.
- **`GET /api/map/stream?scope=…`:** `text/event-stream`, `event: position` with `{id, position, progress, status}`, a `: ping` at least every 15 s, and `X-Accel-Buffering: no` so the Kubernetes/nginx ingress does not buffer. The client reads SSE through `fetch`, so the same cookie or `Authorization` header as the snapshot works. You don't need a token in the URL.

```python
@router.get("/api/map/stream")
async def map_stream(request: Request, scope: str = "customer", user=Depends(current_user)):
    queue = position_bus.subscribe(scope=scope, company_id=user.company_id)   # your tracking ingest
    async def gen():
        yield "retry: 5000\n\n"
        try:
            while not await request.is_disconnected():
                try:
                    ev = await asyncio.wait_for(queue.get(), timeout=15)
                    yield f"event: position\ndata: {json.dumps(ev)}\n\n"
                except asyncio.TimeoutError:
                    yield ": ping\n\n"
        finally:
            position_bus.unsubscribe(queue)
    return StreamingResponse(gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})
```

- **Unknown ids:** an event for an id the client hasn't seen triggers a fresh snapshot after 2 s, so new bookings appear without a reload.
- **Resync:** while live, the client resyncs the whole snapshot every 5 minutes to pick up leg ATD/ATA changes.
- **Seed data:**
  - `fixtures/routes.json`: 67 real lanes, densified to segments of at most 40 km. They cover sea via Suez, the Cape, Kiel and the Danish straits; Baltic ferries; Via Baltica, E4/E8 and the Finnish main roads; the China–Europe rail corridor and Finnish rail via Kouvola; and air routings that respect 2026 airspace.
  - `fixtures/sample-shipments.json`: 55 curated shipments that cover every mode and status.
  - Both can seed MongoDB so the real app has the same geometry. Each file holds a top-level array (`lanes` / `shipments`), so import one document per element:

```bash
jq -c '.shipments[]' fixtures/sample-shipments.json | mongoimport --uri "$MONGO_URL" --db "$DB_NAME" --collection map_shipments --drop
jq -c '.lanes[]'     fixtures/routes.json            | mongoimport --uri "$MONGO_URL" --db "$DB_NAME" --collection map_lanes --drop
```

  The timestamps in `sample-shipments.json` are fixed at 2026-10-24T12:00Z. For data that moves, run `fixtures/server.mjs` or port `fixtures/generate.mjs` (`buildShipments`, `positionAt`) to the back end.

## Run the standalone demo (fixture server)

```bash
cd s2/module            # this package
npm ci
npm run build           # library (dist/) + demo (dist-demo/)
PORT=8787 SIM_SPEED=60 node fixtures/server.mjs &          # contract endpoints + SSE; 60x clock so movement shows
npx vite preview --port 4173                                # production demo on :4173, /api proxied to :8787
# dev mode instead: npx vite   (port 5173)
```

Demo URL parameters:

- `scope=ops|customer`, `customer=<name>`, `count=2000` (load test), `theme=dark`, `locale=en|fi`, `view=europe|finland`, `select=<id>` and `stats=1` (FPS readout).
- Fault injection: `fail=1` (snapshot 503), `stream404=1` (SSE 404, so the client falls back to polling) and `nostream=1` (polling only).

Fixture server:

- **Endpoints:** `/api/map/shipments`, `/api/map/stream` and `/api/map/health`.
- **Environment:** `PORT`, `HOST`, `SIM_SPEED`, `TICK_MS`, `FIXTURE_COUNT` and `FAIL_RATE`.
- **Query:** `?count=` (up to 5000), `?fail=1`, `?delay=ms` and `?nostream=1`.
- **Customer scope:** needs `X-Demo-Customer: <exact name>` or `?customer=`. Without one it returns 401; an unknown customer returns 403.

## Checks

All paths are relative to this module; run from its folder.

```bash
npm test                                                         # bundles src for Node, then 13 tests (feed + attention counts)
node fixtures/validate.mjs                                       # contract + geography validator (needs the server on :8787)
npm run a11y                                                     # axe-core light/dark 1440/390 + keyboard walk (needs the demo on :4173)
node tools/check-fixes.mjs <outDir>                              # browser check: failed load state + attention chip vs filter (demo on :4173)
node tools/evidence.mjs <outDir> shots|states|perf|video         # screenshots, states, FPS at 2,000, MP4
```

Browser tools use `/usr/local/bin/chromium`; set `CHROMIUM_PATH` elsewhere. `DEMO_URL` and `API_URL` override the demo and fixture addresses.

- **Feed tests (`tests/feed.test.mjs`, real HTTP servers):**
  - SSE framing: frames split at every chunk size from 1 to 16 bytes, including CRLF split across reads (fails on the pre-release parser), comments, malformed and unknown events.
  - Fallback and recovery: stream 404 → polling; server-closed stream → reconnect with the server's `retry`; silent half-open stream → watchdog reconnect; failed refresh keeps data; initial failure → retry.
  - Snapshot failing while the stream is healthy: the error is kept, the view is *failed* and never *live*, requests back off, and Retry recovers. This test fails on 1.0.0.
  - Auth headers on both requests; per-shipment contract rejection.
- **Attention tests (`tests/attention.test.mjs`):** on the real fixtures (55 and 2,000 shipments) the chip's customs holds equal the status facet, exceptions and overlaps are exact, and the total equals the rows the attention filter shows. They fail on 1.0.0 (holds 2 vs 4, 8 vs 20).
- **Performance, 2,000 shipments, production build, headless Chromium on an NVIDIA L4:** 60 fps (p95 frame ≈ 17–20 ms) idle with live SSE (2,000 position events every 2 s) and during globe → Europe → Finland flights. Under a 4× CPU throttle, results vary by run: idle 45–50 fps, and flights 26–50 fps (the independent review measured 26–30 fps for flights). Plan for about 30 fps during camera flights on a slow laptop. See `evidence/s2/perf-2000.csv`.

## Known limits and deliberate variances

- **Desktop only for some interactions:** the hover card appears on desktop only; touch users tap a marker or row.
- **Air arcs are exaggerated:** air arcs peak at 5% of the leg length, capped at 600 km. This is a deliberate, readable exaggeration of cruise altitude, not real altitude.
- **Glide, not prediction:** between reports, markers glide straight from the last shown position to the new one. They don't dead-reckon ahead of the data.
- **No label backgrounds on the map's text layer:** deck.gl's TextLayer does not render in MapLibre globe mode, so origin and destination labels are MapLibre HTML markers instead. They are hidden when they fall behind the globe.
- **External tile service:** tiles come from tiles.openfreemap.org. If the business wants no third-party runtime dependency, self-host the OpenFreeMap planet (MIT tooling, ODbL data) and pass `mapStyle`.
